s = `ping 8.8.8.8`

puts s

